---
title: CI/CD-pipeline – monorepo eksempel
---

**Formål:** Sætte en enkel CI/CD op med GitHub Actions, der kører tests, linter og deployer til GitHub Pages.

**Teknikker:** GitHub Actions, caching, matrix builds, artifacts.

**Refleksion:** Hvad var trade-offs ift. buildtid, sikkerhed (secrets), og miljøer?
