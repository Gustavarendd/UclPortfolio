---
layout: page
title: Refleksioner
permalink: /refleksioner/
---

Løbende refleksioner om læring, fremskridt og udfordringer. Brug evt. blogindlæg i `_posts/` for dato-stemplede refleksioner.
