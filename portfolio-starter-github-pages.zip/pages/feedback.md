---
layout: page
title: Feedback
permalink: /feedback/
---

Saml feedback fra undervisere og medstuderende. Tilføj egne noter om, hvad du ændrer baseret på feedbacken.
