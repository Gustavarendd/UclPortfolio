---
layout: home
title: Velkommen
---

# Velkommen

Denne portefølje samler mit arbejde i efterårssemesteret 2025 inden for **Automatisering & Scripting** og **Cloud Computing & DevOps**.

- 📁 [Projekter](/projects/)
- 📝 [Refleksioner](/refleksioner/)
- 💬 [Feedback](/feedback/)
- 🔗 [Ressourcer](/ressourcer/)
- 🎯 [Mål](/maal/)

> *Opsætningen er bygget med GitHub Pages (Jekyll + minima).*
